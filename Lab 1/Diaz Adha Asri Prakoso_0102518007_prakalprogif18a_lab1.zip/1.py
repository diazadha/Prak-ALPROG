print ("Hello, world!")
print ("Saya senang menemani anda belajar Python")
input ()
