a = "True"
b = "False"
# Hi! I'm Maria and I live in script.py.
# I'm an expert Python coder.
# I'm 21 years old and I plan to program cool stuff forever.
usia_12 = b
name_is_maria = a
print ("Apakah berusia 12 : ", usia_12)
print ("Apakah bernama Maria : ", name_is_maria)

input()
