float1 = 2.5
float2 = 5.5
produk = float1 * float2
string = "Nilai Produk adalah " + str(produk)
print (string)

input ()
