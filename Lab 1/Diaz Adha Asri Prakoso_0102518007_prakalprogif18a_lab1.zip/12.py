nama = "Diaz Adha"
usia = "19"
hobi = "Main piano"
print (nama,usia,hobi)

input ()
