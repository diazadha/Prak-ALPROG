string = 'There\s a snake in my boot!'
print (string)
input ()
