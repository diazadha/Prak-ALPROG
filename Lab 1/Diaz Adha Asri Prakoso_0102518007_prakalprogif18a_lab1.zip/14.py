angka_keenam = '"EMPAT"'[6]
print (angka_keenam)

input ()
