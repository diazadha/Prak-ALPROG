pi = 3.14
a = "Nilai dari konstanta pi adalah " + str(pi)
print (a)
print (a.upper())
print (a.lower())
print (len(a))

input ()
