string1 = "Jakarta"
string2 = "Macet"
print ("Janganlah pergi ke %s, karena merupakan kota yang %s" %(string1,string2))
nama_lengkap = input("Siapakah nama lengkap anda?")
nama_panggilan = input("Nama panggilanya siapa?")
warna = input("Apa warna kesukaan anda?")
print ("Ah, jadi nama anda adalah %s, panggilanya %s,dan warna favorit anda adalah %s" %(nama_lengkap,nama_panggilan,warna))

input ()
