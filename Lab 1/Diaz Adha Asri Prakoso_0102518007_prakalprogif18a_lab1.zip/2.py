print ("Ini adalah String")
print ('Anda dapat menggunakan tanda petik satu maupun petik dua')
print ("Ini adalah "+"String")
print ("Halo "+"Diaz Adha Asri Prakoso")

input()
