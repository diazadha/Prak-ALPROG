print ("Assalamualaikum, bagaimana kabar Anda pagi ini?")
print ('Harap menjauh dariku!')

input ()
