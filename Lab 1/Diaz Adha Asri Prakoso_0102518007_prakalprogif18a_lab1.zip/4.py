tanggal_hari_ini = 15

print ("Tanggal hari ini : ", +tanggal_hari_ini)
input ()
