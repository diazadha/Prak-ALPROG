jumlah = 253 * 500
print ("Hasil perkalianya adalah", +jumlah)
remainder = 1398%11
print ("Sisa pembagian bilangan tersebut adalah", +remainder)

input()
