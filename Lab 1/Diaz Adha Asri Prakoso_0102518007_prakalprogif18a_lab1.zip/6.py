uang_yang_dimiliki = 450000
print ("Beli sepatu")
harga_sepatu = 150000
diskon = (50/100) * harga_sepatu
harga_sepatu -= diskon
uang_yang_dimiliki -= harga_sepatu
print ("Harga sepatu setelah diskon : ", +harga_sepatu)
print ("Sisa uang yang dimiliki : ", +uang_yang_dimiliki)

input()
