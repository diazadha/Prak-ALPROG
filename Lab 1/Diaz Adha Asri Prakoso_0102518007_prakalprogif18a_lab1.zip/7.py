x = 12 # Variabel bilangan bulat pertama
y = 15 # Variabel bilangan bulat kedua

input()
