a = 7/2
print ("Nilai a : ", +a)
b = 7/3
print ("Nilai b : ", +b)
# Tipe data a adalah float
# Tipe data b adalah float
harga_Wortel = 2000
harga_Kubis = 1000
harga_Mentimun = 1000
harga_Tomat = 1500
harga_Kol = 550
total_harga = ((harga_Wortel)+(harga_Kubis*3)+(harga_Mentimun*4)+(harga_Tomat*5)+(harga_Kol*(1/2)))
print ("Total harga yang harus dibayar : ", +total_harga)
# Tipe data variabel total_harga yang dihasilkan adalah integer

input ()
