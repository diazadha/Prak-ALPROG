sertifikat = """	SERTIFIKAT DIBERIKAN KEPADA
	DIAZ ADHA ASRI PRAKOSO"""
print (sertifikat)

input()
