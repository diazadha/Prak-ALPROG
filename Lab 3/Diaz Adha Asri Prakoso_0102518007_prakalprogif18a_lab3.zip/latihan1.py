def nama_fungsi():
    print ("Halo dari fungsi saya")


