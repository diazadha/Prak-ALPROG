kata = (input("Masukkan nama : "))
balik = "".join(reversed(kata))
print (balik)
