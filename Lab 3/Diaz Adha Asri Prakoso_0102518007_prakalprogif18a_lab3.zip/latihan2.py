def fungsi_saya():
    print ("Halo dari fungsi saya")

fungsi_saya()
