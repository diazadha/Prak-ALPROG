def fungsi_saya(nama, alamat):
    print (nama)

nama = 'Diaz Adha Asri Prakoso'
alamat = 'alamat'
fungsi_saya(nama,alamat)
