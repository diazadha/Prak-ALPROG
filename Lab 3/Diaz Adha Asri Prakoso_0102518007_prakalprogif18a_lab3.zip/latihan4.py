def fungsi_saya(x):
    return x+5


    
