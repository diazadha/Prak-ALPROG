def hello_world():
    print ("Hello World!") #mencetak tulisan Hello World! ke layar

hello_world() #memanggil fungsi
