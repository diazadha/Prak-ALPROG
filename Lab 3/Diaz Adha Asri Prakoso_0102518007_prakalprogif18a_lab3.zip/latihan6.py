def square(n):
    squared = n ** 2 #Mengkuadratkan bilangan
    print ("%d kuadrat adalah %d" %(n, squared))
    return squared

#panggil fungsi dengan n = 10
square(10)
