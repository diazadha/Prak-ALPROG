answer = int(input("Masukkan angka : "))
while answer != 7:
    print ("Jawabanya salah, silahkan coba lagi!")
    answer = int(input("Masukkan angka : "))
else:
    print ("Jawabanya benar!!")
