bintang = ""
i=1
while i <= 5:
    j=1
    while j <= i:
        bintang = bintang + "*"
        j = j + 1
    bintang = bintang + "\n"
    i = i + 1

a= 1
d = 4
while  a <= 4:
    b = 1
    while b <= d :
        bintang = bintang + "*"
        b = b + 1
    bintang = bintang + "\n"
    d = d - 1
    a = a + 1
print (bintang)

